// Listen for messages from the user interface
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    // Get all tabs in the current window
    chrome.tabs.query({ currentWindow: true }, function(tabs) {
      // Loop through the tabs
      let groups = {};
      tabs.forEach(function(tab) {
        // Get the title and URL of the tab
        let title = tab.title.toLowerCase();
        let url = tab.url.toLowerCase();
  
        // Check if the title or URL contains the prompt
        if (title.includes(request.prompt) || url.includes(request.prompt)) {
          // Add the tab to the appropriate group
          let domain = url.match(/^[\w-]+:\/*\[?([\w\.:-]+)\]?(?::\d+)?/)[1];
          if (!groups[domain]) {
            groups[domain] = [];
          }
          groups[domain].push(tab.id);
        }
      });
  
      // Create tab groups
      for (let domain in groups) {
        chrome.tabs.group({tabIds: groups[domain]}, function(group) {
          console.log('Grouped tabs:', group);
        });
      }
    });
  });
  