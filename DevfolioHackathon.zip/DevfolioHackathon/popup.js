// Get the elements
const promptInput = document.getElementById('prompt-input');
const groupTabsButton = document.getElementById('group-tabs-button');

// Add a click event listener to the button
groupTabsButton.addEventListener('click', () => {
  // Get the prompt value
  const promptValue = promptInput.value.trim();

  // Check if the prompt value is not empty
  if (promptValue) {
    // Send a message to the background script with the prompt value
    chrome.runtime.sendMessage({prompt: promptValue});
  }
});
